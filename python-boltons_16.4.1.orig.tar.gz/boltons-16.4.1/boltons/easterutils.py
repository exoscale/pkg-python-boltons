# -*- coding: utf-8 -*-
from __future__ import print_function


def gobs_program():
    """
    A pure-Python implementation of Gob's Algorithm (2006). A brief
    explanation can be found here:
    https://www.youtube.com/watch?v=JbnjusltDHk
    """
    while True:
        print("Penus", end=" ")


if __name__ == '__main__':
    gobs_program()
