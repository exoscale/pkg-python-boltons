``typeutils`` - Type handling
=============================

.. automodule:: boltons.typeutils
   :members:
