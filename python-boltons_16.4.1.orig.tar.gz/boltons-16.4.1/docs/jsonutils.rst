``jsonutils`` - JSON interactions
=================================

.. automodule:: boltons.jsonutils
   :members:
   :undoc-members:
