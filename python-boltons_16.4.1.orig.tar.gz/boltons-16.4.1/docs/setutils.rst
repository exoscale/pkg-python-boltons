``setutils`` - ``IndexedSet`` type
==================================

.. automodule:: boltons.setutils
   :members:
