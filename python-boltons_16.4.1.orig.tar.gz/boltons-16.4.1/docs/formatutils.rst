``formatutils`` - ``str.format()`` toolbox
==========================================

.. automodule:: boltons.formatutils
   :members:
   :undoc-members:
