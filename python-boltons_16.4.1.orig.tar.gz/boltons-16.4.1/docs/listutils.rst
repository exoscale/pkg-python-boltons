``listutils`` - ``list`` derivatives
====================================

.. automodule:: boltons.listutils
   :members:
   :undoc-members:
